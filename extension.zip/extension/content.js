// You can track user interaction on pages here or collect additional data
console.log("Content script loaded");
